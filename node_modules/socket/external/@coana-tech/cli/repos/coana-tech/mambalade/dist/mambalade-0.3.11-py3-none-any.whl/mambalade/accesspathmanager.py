from __future__ import annotations
from abc import abstractmethod
from dataclasses import dataclass,field
from typing import TYPE_CHECKING,Final,TypeAlias,final
from.typing import TypeABC
from.util import dfield
if TYPE_CHECKING:from collections import defaultdict;from.infos import CallEdgeSource,ModuleIdentifier,QualifiedNode
class _AccessPathBase(TypeABC):
	@abstractmethod
	def __str__(self):...
	@abstractmethod
	def __eq__(A,B):...
	@abstractmethod
	def __hash__(self):...
@final
class ImportAccessPath(_AccessPathBase):
	def __init__(A,module_identifier):super().__init__();A.module_identifier=module_identifier
	def __str__(A):return f"<{A.module_identifier}>"
	def __eq__(B,other):A=other;return isinstance(A,ImportAccessPath)and B.module_identifier==A.module_identifier
	def __hash__(A):return hash((type(A),A.module_identifier))
@final
class ReadAccessPath(_AccessPathBase):
	def __init__(A,name):super().__init__();A.name=name
	def __str__(A):return A.name
	def __eq__(B,A):return isinstance(A,ReadAccessPath)and B.name==A.name
	def __hash__(A):return hash((type(A),A.name))
@final
class CallAccessPath(_AccessPathBase):
	def __init__(A,node):super().__init__();A.node=node
	def __str__(A):return f"<call {A.node}>"
	def __eq__(B,A):return isinstance(A,CallAccessPath)and B.node==A.node
	def __hash__(A):return hash((type(A),A.node))
if TYPE_CHECKING:AccessPath=ReadAccessPath|CallAccessPath|ImportAccessPath
else:AccessPath=_AccessPathBase
@final
@dataclass(slots=True)
class AccessPathsManager:
	module_access_paths:Final[set[ImportAccessPath]]=field(default_factory=set,init=False);read_access_paths:Final[defaultdict[tuple[AccessPath,str],set[tuple[AccessPath,CallEdgeSource]]]]=dfield(set);call_access_paths:Final[defaultdict[AccessPath,set[tuple[AccessPath,CallEdgeSource]]]]=dfield(set)
	def add_import_access_path(A,path):A.module_access_paths.add(path)
	def add_read_access_path(A,path,sub_ap,caller):A.read_access_paths[sub_ap,path.name].add((path,caller))
	def add_call_access_path(A,path,sub_ap,caller):A.call_access_paths[sub_ap].add((path,caller))