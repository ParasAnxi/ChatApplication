from __future__ import annotations
_H='lambda self, n, /: 2'
_G='__mul__'
_F='lambda self, other, /: 2'
_E='__add__'
_D='lambda self, index, /: 2'
_C='__getitem__'
_B='lambda self, /: 1'
_A=None
import ast,logging
from dataclasses import replace
from typing import TYPE_CHECKING,assert_type,final
from typing_extensions import override
from mambalade.calls import AbstractArgs,CallData
from mambalade.infos import SynthProp
from mambalade.listeners import Listener,ListenerKey
from mambalade.tokens import AccessPathToken,ObjectToken,Token,TypeToken,UnknownToken
from mambalade.util import Singleton
from mambalade.vars import ConstraintVar,PropVar,SeqIndexVar
from.core import Object
from.helpers import NativeType,generic_class_getitem,native_function,native_method,native_type
from.iterator import IteratorToken
if TYPE_CHECKING:from mambalade.calls import AbstractArg;from mambalade.operations import Operations;from.core_tokens import NativeTypeToken
logger=logging.getLogger(__name__)
@native_function('sequence.__iter__',spec=_B)
def seq_iter(op,d):
	if isinstance((A:=d.args.args[0]),Token|ConstraintVar):
		def B(seq):
			A=seq
			match A:
				case EmptyTupleToken():pass
				case ObjectToken()if any(A in(List,Tuple)for A in A.typ.mro):op.return_value(d,IteratorToken(A,PropVar(A,SynthProp.SEQ_ALL)))
				case _:logger.debug('Ignoring sequence.__iter__ for non-sequence %s',A)
		op.forall_constraint_uncached(A,ListenerKey(Listener.NATIVE_SEQ__ITER__,parent=d.parent),B)
def _seq_merge(op,to,frm):op.solver.add_subset_constraint(PropVar(frm,SynthProp.SEQ_ALL),PropVar(to,SynthProp.SEQ_UNKNOWN))
def getitem_impl(op,seq,index,d,seqtyp):
	E=index;B=seq;A=op
	match E:
		case int(D)if D>=0:A.return_value(d,SeqIndexVar(B,D));A.return_value(d,PropVar(B,SynthProp.SEQ_UNKNOWN))
		case ast.Slice():
			F=seqtyp.new_instance(A,d);A.return_value(d,F)
			match E.lower:
				case ast.Constant(value=int(C)):pass
				case None:C=0
				case _:C=_A
			match(C,E.upper,E.step):
				case int(),ast.Constant(value=int(G)),ast.Constant(value=int(1))|None if 0<=C<=G<10:
					A.solver.add_subset_constraint(PropVar(B,SynthProp.SEQ_UNKNOWN),PropVar(F,SynthProp.SEQ_UNKNOWN))
					for D in range(C,G):A.solver.add_subset_constraint(SeqIndexVar(B,D),SeqIndexVar(F,D-C))
				case _:_seq_merge(A,F,B)
		case _:A.return_value(d,PropVar(B,SynthProp.SEQ_ALL))
def _smash_list(op,li):op.solver.add_subset_constraint(PropVar(li,SynthProp.SEQ_ALL),PropVar(li,SynthProp.SEQ_UNKNOWN))
@native_type(Object,unsupported_methods=('__delitem__',))
class List(NativeType):
	@native_method('__init__',spec='lambda self, iterable=(), /: 1')
	@staticmethod
	def init(op,d):
		A=d.args
		if A.unpack_iter is not _A:op.a.warn_unsupported(d.callnode,'list.__init__ with *args')
		if len(A.args)==2 and isinstance((C:=A.args[1]),Token|ConstraintVar):
			match A.args[0]:
				case ConstraintVar():op.a.warn_unsupported(d.callnode,'list.__init__ with non-constant list')
				case ObjectToken(D)as B if List in D.mro:E=ListenerKey(Listener.NATIVE_LIST__INIT__,parent=d.parent);op.unpack_iterable_into(C,replace(d,args=AbstractArgs.empty,res=PropVar(B,SynthProp.SEQ_UNKNOWN),parent=E))
				case B:logger.debug('Ignoring list.__init__ for non-list %s',B)
	__class_getitem__=generic_class_getitem;__iter__=seq_iter
	@native_method(_C,spec=_D)
	@staticmethod
	def getitem(op,d):
		A,B=d.args.args
		if isinstance(A,Token|ConstraintVar):
			def C(li):
				if isinstance(li,ObjectToken)and List in li.typ.mro:getitem_impl(op,li,B,d,List)
				else:logger.debug('Ignoring list.__getitem__ for non-list %s',li)
			op.forall_constraint_uncached(A,ListenerKey(Listener.NATIVE_LIST__GETITEM__,parent=d.parent),C)
	@native_method('__setitem__',spec='lambda self, index, value, /: 3')
	@staticmethod
	def setitem(op,d):
		A,C,B=d.args.args
		if B is _A:return
		assert isinstance(B,Token|ConstraintVar)
		if isinstance(A,Token|ConstraintVar):
			def D(li):
				A=li
				if not isinstance(A,ObjectToken)or List not in A.typ.mro:logger.debug('Ignoring list.__setitem__ for non-list %s',A);return
				match C:
					case int(D):op.inclusion_constraint(B,SeqIndexVar(A,D))
					case ast.Slice():E=ListenerKey(Listener.NATIVE_LIST__SETITEM__SLICE,token=A,parent=d.parent);F=replace(d,args=AbstractArgs.empty,res=PropVar(A,SynthProp.SEQ_UNKNOWN),parent=E);op.unpack_iterable_into(B,F)
					case str():pass
					case _:op.inclusion_constraint(B,PropVar(A,SynthProp.SEQ_UNKNOWN))
			op.forall_constraint_uncached(A,ListenerKey(Listener.NATIVE_LIST__SETITEM__,parent=d.parent),D)
	@native_method('append',spec='lambda self, object, /: 2')
	@staticmethod
	def append(op,d):
		A,B=d.args.args
		if not isinstance(B,Token|ConstraintVar):return
		if isinstance(A,Token|ConstraintVar):
			def C(li):
				if not isinstance(li,ObjectToken)or List not in li.typ.mro:logger.debug('Ignoring list.append for non-list %s',li);return
				op.inclusion_constraint(B,PropVar(li,SynthProp.SEQ_UNKNOWN))
			op.forall_constraint_uncached(A,ListenerKey(Listener.NATIVE_LIST_APPEND,parent=d.parent),C)
	@native_method('insert',spec='lambda self, index, object, /: 1')
	@staticmethod
	def insert(op,d):
		if not isinstance((A:=d.args.args[0]),ObjectToken)or List not in A.typ.mro:logger.debug('Ignoring list.insert for non-list %s',A);return
		_smash_list(op,A)
		if len(d.args.args)==3:
			if isinstance((B:=d.args.args[2]),Token|ConstraintVar):op.inclusion_constraint(B,PropVar(A,SynthProp.SEQ_UNKNOWN))
		else:assert d.args.unpack_iter is not _A;op.a.warn_unsupported(d.callnode,'list.insert with iterable unpacking')
	@native_method('extend',spec='lambda self, iterable, /: 2')
	@staticmethod
	def extend(op,d):
		A,B=d.args.args
		if not isinstance(A,ObjectToken)or List not in A.typ.mro:logger.debug('Ignoring list.extend for non-list %s',A);return
		if isinstance(B,Token|ConstraintVar):C=ListenerKey(Listener.NATIVE_LIST_EXTEND,parent=d.parent);op.unpack_iterable_into(B,replace(d,args=AbstractArgs.empty,res=PropVar(A,SynthProp.SEQ_UNKNOWN),parent=C))
	@native_method('pop',spec='lambda self, index=-1, /: 1')
	@staticmethod
	def pop(op,d):
		if not isinstance((A:=d.args.args[0]),ObjectToken)or List not in A.typ.mro:logger.debug('Ignoring list.pop for non-list %s',A);return
		if d.args.num_definite_pos_args>1:_smash_list(op,A)
		op.return_value(d,PropVar(A,SynthProp.SEQ_ALL))
	@native_method('remove',spec='lambda self, value, /: 1')
	@staticmethod
	def remove(op,d):
		if not isinstance((A:=d.args.args[0]),ObjectToken)or List not in A.typ.mro:logger.debug('Ignoring list.remove for non-list %s',A);return
		_smash_list(op,A)
	@native_method('reverse',spec=_B)
	@staticmethod
	def reverse(op,d):
		if not isinstance((A:=d.args.args[0]),ObjectToken)or List not in A.typ.mro:logger.debug('Ignoring list.reverse for non-list %s',A);return
		_smash_list(op,A)
	@native_method('copy',spec=_B)
	@staticmethod
	def copy(op,d):
		if not isinstance((A:=d.args.args[0]),ObjectToken)or List not in A.typ.mro:logger.debug('Ignoring list.copy for non-list %s',A);return
		B=List.new_instance(op,d);_seq_merge(op,B,A);op.return_value(d,B)
	@native_method('sort',spec='lambda self, /, *, key=None, reverse=False: 1')
	@staticmethod
	def sort(op,d):
		if not isinstance((A:=d.args.args[0]),ObjectToken)or List not in A.typ.mro:logger.debug('Ignoring list.sort for non-list %s',A);return
		_smash_list(op,A)
		for(B,C)in d.args.kwargs or():
			if B is _A:op.a.warn_unsupported(d.callnode,'list.sort with mapping unpacking')
			elif B=='key'and isinstance(C,Token|ConstraintVar):D=ListenerKey(Listener.NATIVE_LIST_SORT,parent=d.parent);op.invoke_object(C,replace(d,args=AbstractArgs.seq(PropVar(A,SynthProp.SEQ_ALL)),res=_A,parent=D))
	@native_method(_E,spec=_F)
	@staticmethod
	def add(op,d):
		A=op;B,D=d.args.args
		if not isinstance(B,ObjectToken)or List not in B.typ.mro:logger.debug('Ignoring list.__add__ for non-list %s',B);return
		C=List.new_instance(A,d);_seq_merge(A,C,B);A.return_value(d,C)
		if not isinstance(D,Token|ConstraintVar):return
		def E(t):
			match t:
				case ObjectToken()if List in t.typ.mro:_seq_merge(A,C,t)
				case UnknownToken():A.return_value(d,t)
				case _:
					if TYPE_CHECKING:assert_type(t,AccessPathToken|ObjectToken)
		A.forall_constraint_uncached(D,ListenerKey(Listener.NATIVE_LIST__ADD__,parent=d.parent),E)
	@native_method(_G,spec=_H)
	@staticmethod
	def mul(op,d):
		A,B=d.args.args
		if not isinstance(A,ObjectToken)or List not in A.typ.mro:logger.debug('Ignoring list.__mul__ for non-list %s',A);return
		match B:
			case int()|ConstraintVar():pass
			case _:logger.debug('Ignoring list.__mul__ with non-integer multiplier %s',B);return
		C=List.new_instance(op,d);_seq_merge(op,C,A);op.return_value(d,C)
@native_type(Object)
class Tuple(NativeType):
	@native_method('__new__',spec='lambda cls, iterable=(), /, **kwargs: 1')
	@staticmethod
	def new(op,d):
		A=op;B,*C=d.args.args
		if not isinstance(B,Token|ConstraintVar):logger.debug('Ignoring tuple.__new__ with non-token class');return
		if C and isinstance((E:=C[0]),Token|ConstraintVar):
			def D(B):
				A.return_value(d,B);C=PropVar(B,SynthProp.SEQ_UNKNOWN)
				def D(t):
					match t:
						case ObjectToken(D)if D is Tuple and B.typ is Tuple:A.return_value(d,t)
						case ObjectToken():E=ListenerKey(Listener.NATIVE_TUPLE__NEW__ITERABLE,(d.callnode.node,d.context),token=B);A.unpack_iterable_into(t,replace(d,args=AbstractArgs.empty,res=C,parent=E))
						case UnknownToken():A.solver.add_token_constraint(t,C)
						case AccessPathToken():pass
				A.forall_constraint_uncached(E,ListenerKey(Listener.NATIVE_TUPLE__NEW__,token=B,parent=d.parent),D)
		else:
			def D(B):A.return_value(d,B)
		def F(t):
			match t:
				case TypeToken()if Tuple in t.mro:D(t.new_instance(A,d))
				case UnknownToken():A.return_value(d,t)
				case _:
					if TYPE_CHECKING:assert_type(t,AccessPathToken|ObjectToken)
		A.forall_constraint_uncached(B,ListenerKey(Listener.NATIVE_TUPLE__NEW__,parent=d.parent),F)
	__class_getitem__=generic_class_getitem;__iter__=seq_iter
	@native_method(_C,spec=_D)
	@staticmethod
	def getitem(op,d):
		A,B=d.args.args
		if isinstance(A,Token|ConstraintVar):
			def C(t):
				match t:
					case EmptyTupleToken():pass
					case ObjectToken()if Tuple in t.typ.mro:getitem_impl(op,t,B,d,Tuple)
					case _:logger.debug('Ignoring tuple.__getitem__ for non-tuple %s',t)
			op.forall_constraint_uncached(A,ListenerKey(Listener.NATIVE_TUPLE__GETITEM__,parent=d.parent),C)
	@native_method(_E,spec=_F)
	@staticmethod
	def add(op,d):
		A=op;B,D=d.args.args
		if not isinstance(B,ObjectToken)or Tuple not in B.typ.mro:logger.debug('Ignoring tuple.__add__ for non-tuple %s',B);return
		C=Tuple.new_instance(A,d);A.return_value(d,C)
		if B.typ is Tuple:A.return_value(d,B)
		else:_seq_merge(A,C,B)
		if not isinstance(D,Token|ConstraintVar):return
		def E(t):
			match t:
				case ObjectToken()if Tuple in t.typ.mro:_seq_merge(A,C,t)
				case UnknownToken():A.return_value(d,t)
				case _:
					if TYPE_CHECKING:assert_type(t,AccessPathToken|ObjectToken)
		A.forall_constraint_uncached(D,ListenerKey(Listener.NATIVE_TUPLE__ADD__,parent=d.parent),E)
	@native_method(_G,spec=_H)
	@staticmethod
	def mul(op,d):
		A,B=d.args.args
		if not isinstance(A,ObjectToken)or Tuple not in A.typ.mro:logger.debug('Ignoring tuple.__mul__ for non-tuple %s',A);return
		match B:
			case int()|ConstraintVar():pass
			case _:logger.debug('Ignoring tuple.__mul__ with non-integer multiplier %s',B);return
		C=Tuple.new_instance(op,d);_seq_merge(op,C,A);op.return_value(d,C)
@final
class EmptyTupleToken(Singleton,ObjectToken):
	typ=Tuple;immutable=True
	@override
	def __str__(self):return'EmptyTuple'
	@override
	def _lookup_attr(self,attr):return _A,False