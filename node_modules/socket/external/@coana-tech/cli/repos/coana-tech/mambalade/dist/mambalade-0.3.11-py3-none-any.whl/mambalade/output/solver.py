from __future__ import annotations
_A='tokens'
import json
from typing import TYPE_CHECKING
from mambalade.tokens import Token,TypeToken,UnknownToken
if TYPE_CHECKING:
	from pathlib import Path;from typing_extensions import TypedDict;from mambalade.listeners import ListenerKey;from mambalade.solver import Solver
	class SolverStats(TypedDict,closed=True):iterations:int;tokens:int;subset_edges:int;vars:int;listeners:int;listeners_token:int;listeners_objprops:int;listener_max_depth:int;processed_listeners:int;class_tokens:int;unique_classes:int;unique_tokens:int;unknown_tokens_per_var:float
def _listener_depth(key):
	A=key;B=0
	while A is not None:B+=1;A=A.parent
	return B
def solver_stats(s):A={B for A in s._tokens.values()for B in A};B=[A for A in A if isinstance(A,TypeToken)and A.user_defined is not None];C=sum(len(A)for A in s._listeners.values());D=sum(len(A)for A in s._module_props_listeners.values());return{'iterations':s._iterations,_A:sum(len(A)for A in s._tokens.values()),'subset_edges':sum(len(A)for A in s._subset_edges.values()),'vars':len(s.all_vars()),'listeners':C+D,'listeners_token':C,'listeners_objprops':D,'listener_max_depth':max((_listener_depth(B)for A in s._listeners.values()for B in A),default=0),'processed_listeners':sum(len(A)for A in s._listeners_processed.values()),'class_tokens':len(B),'unique_classes':len({A.user_defined for A in B}),'unique_tokens':len(A),'unknown_tokens_per_var':sum(UnknownToken()in A for A in s._tokens.values())/max(1,len(s._tokens))}
def dump_solution(s,path):
	A={};vars=[]
	for(B,C)in s._tokens.items():vars.append((str(B),[A.setdefault(B,len(A))for B in C]))
	vars.sort(key=lambda x:x[0])
	with path.open('w',encoding='utf-8')as D:json.dump({_A:[str(A)for A in A],'vars':vars},D)