from __future__ import annotations
_A=None
import importlib.abc,logging
from dataclasses import dataclass,field
from importlib.machinery import SOURCE_SUFFIXES,BuiltinImporter,FileFinder,ModuleSpec,SourceFileLoader
from pathlib import Path
from typing import TYPE_CHECKING,Final,final
from.import util
from.infos import ModuleIdentifier,ModuleInfo,ModuleKind
from.natives.modules import NativeModuleImporter
if TYPE_CHECKING:import types;from collections.abc import Sequence;from.globalstate import GlobalState
logger=logging.getLogger(__name__)
@dataclass(frozen=True)
class CustomPathFinder(importlib.abc.MetaPathFinder):
	sys_path:Final[Sequence[str]];_path_cache:Final=field(default_factory=dict[str,FileFinder],init=False)
	def _get_finder(B,path):
		A=path
		if(C:=B._path_cache.get(A))is _A:C=B._path_cache[A]=FileFinder(A,(SourceFileLoader,SOURCE_SUFFIXES))
		return C
	def _get_spec(E,fullname,path):
		B=fullname;C=[];assert path
		for F in path:
			A=E._get_finder(F).find_spec(B,_A)
			if A is _A:continue
			if A.loader is not _A:return A
			D=A.submodule_search_locations
			if D is _A:raise ImportError('spec missing loader')
			C.extend(D)
		A=ModuleSpec(B,_A);A.submodule_search_locations=C;return A
	def find_spec(C,fullname,path,target=_A):
		B=path;assert target is _A
		if B is _A:B=C.sys_path
		A=C._get_spec(fullname,B)
		if A is _A:return
		elif A.loader is _A:
			if A.submodule_search_locations:A.origin=_A;return A
			else:return
		else:return A
builtin_importer=BuiltinImporter
@final
class Importer:
	__slots__='_excluded_re','a','finders'
	def __init__(A,a):
		A.a=a;A._excluded_re=util.compile_module_regex(C)if(C:=a.options.excluded_modules)else _A;A.finders=[]
		if(B:=a.program.sys_path):assert all(A.is_absolute()and A.is_dir()for A in B);A.finders.append(CustomPathFinder(list(map(str,B))))
		A.finders.append(NativeModuleImporter())
	def import_module(D,name,*,warn_if_missing=True):
		J=warn_if_missing;A=name;C=D.a
		if A=='typing_extensions':A=ModuleIdentifier('typing')
		if A in C.modules:return C.modules[A]
		elif A in C.unresolved_imports:raise ModuleNotFoundError(f"Could not find module '{A}'")
		try:
			E=_A;H=_A;F,M,M=A.rpartition('.')
			if F:
				E=D.import_module(ModuleIdentifier(F),warn_if_missing=J);H=E.spec.submodule_search_locations
				if H is _A:raise ModuleNotFoundError(f"No module named '{A}'; {F} is not a package")
			for N in D.finders:
				B=N.find_spec(A,H)
				if B is not _A:
					assert B.name==A
					if E is not _A and B.submodule_search_locations is _A:assert B.parent==F
					if E is not _A:G=E.kind
					if B.origin=='native':G=ModuleKind.NATIVE
					else:
						if B.origin is _A:I=B.submodule_search_locations;assert I
						else:I=B.origin,
						G=ModuleKind.LIBRARY if any('site-packages'in Path(A).parts for A in I)else ModuleKind.APP
					K=D._excluded_re is not _A and G==ModuleKind.LIBRARY and bool(D._excluded_re.match(A));L=C.modules[A]=ModuleInfo(B,G,K)
					if not K:C.worklist.append(L)
					return L
			raise ModuleNotFoundError(f"Could not find module '{A}'")
		except ModuleNotFoundError as O:
			if J:
				C.unresolved_imports.add(A)
				if not util.is_stdlib_module(A):logger.warning("Import error for '%s': %s",A,O.msg)
			raise