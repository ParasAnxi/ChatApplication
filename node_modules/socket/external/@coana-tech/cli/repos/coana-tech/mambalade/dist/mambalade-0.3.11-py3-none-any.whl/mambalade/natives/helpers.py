from __future__ import annotations
_B=False
_A=None
import ast,functools,logging
from dataclasses import dataclass
from typing import TYPE_CHECKING,Final,Literal,cast,overload
from mambalade.calls import CallData,ParameterList
from mambalade.infos import Native
from mambalade.tokens import Token,UnknownToken
from mambalade.util import simple_cache
from mambalade.vars import ConstraintVar
from.core_tokens import ClassMethodToken,NativeFunctionSpec,NativeFunctionToken,NativeTypeToken
if TYPE_CHECKING:from collections.abc import Callable,Iterable;from mambalade.operations import Operations;from mambalade.tokens import NativeFunctionImpl
logger=logging.getLogger(__name__)
class NativeType:__new__:MethodSlotDef|NativeFunctionToken|_A
@dataclass(frozen=True)
class MethodSlotDef:t:Final[NativeFunctionToken]
@overload
def native_function(name,*,supports_kwargs):...
@overload
def native_function(name,*,supports_kwargs,method):...
@overload
def native_function(name,*,spec=_A):...
@overload
def native_function(name,*,spec=_A,method):...
_nspec_args=NativeFunctionSpec(ParameterList([],{},'args',_A),0)
@simple_cache
def _parse_spec(spec):
	match ast.parse(spec,mode='eval'):
		case ast.Expression(ast.Lambda(args,ast.Constant(int(required_known_pos)))):return NativeFunctionSpec(ParameterList.from_ast(args),required_known_pos)
		case _:raise AssertionError(f"Invalid spec: {spec}")
def native_function(name,*,supports_kwargs=_B,spec=_A,method=_B):
	if spec is _A:nspec=_A if supports_kwargs else _nspec_args
	else:nspec=_parse_spec(spec)
	def decorator(impl):
		if isinstance(impl,staticmethod):impl=cast('NativeFunctionImpl',impl.__func__)
		t=NativeFunctionToken(Native(name),impl,nspec);return MethodSlotDef(t)if method else t
	return decorator
native_method=functools.partial(native_function,method=True)
def native_type(*bases,tname=_A,unsupported_methods=(),mark_unsupported=_B):
	def decorator(cls):
		kind=Native(tname if tname is not _A else cls.__name__.lower());known_slots={}
		for(name,value)in vars(cls).items():
			match value:
				case MethodSlotDef(NativeFunctionToken(Native(name))as t):known_slots[name]=NativeFunctionToken(Native(f"{kind.name}.{name}"),t.impl,t.spec)
				case NativeFunctionToken()|ClassMethodToken():known_slots[name]=value
				case _:pass
		for name in unsupported_methods:assert name not in known_slots,name;known_slots[name]=unsupported_native(f"{kind.name}.{name}")
		return NativeTypeToken(kind,bases,known_slots=known_slots,unsupported=mark_unsupported)
	return decorator
def unsupported_native(name,impl=_A):
	def wrapper(op,d):
		op.a.warn_unsupported(d.callnode,name)
		if impl is not _A:impl(op,d)
	return NativeFunctionToken(Native(name),wrapper,_A)
def return_unknown(op,d):op.return_value(d,UnknownToken())
@native_function('generic_class_getitem',spec='lambda cls, sub, /: 1')
def generic_class_getitem(op,d):
	if isinstance((cls:=d.args.args[0]),Token|ConstraintVar):op.return_value(d,cls)