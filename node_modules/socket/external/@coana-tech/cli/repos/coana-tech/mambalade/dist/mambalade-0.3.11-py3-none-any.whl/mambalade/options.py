from __future__ import annotations
_C=False
_B=None
_A=True
import enum,os,sys
from dataclasses import dataclass,field
from pathlib import Path
from typing import TYPE_CHECKING,Final
if TYPE_CHECKING:from collections.abc import Collection;from datetime import timedelta
class ContextSensitivity(enum.Enum):
	OFF='No context sensitivity';EMPTY='Empty contexts (reachability only)';HEURISTICS='Apply context sensitivity heuristically';CS1='Heuristics + one-level context sensitivity'
	def need_freevars(A):return A in{ContextSensitivity.HEURISTICS,ContextSensitivity.CS1}
@dataclass(frozen=_A,slots=_A,kw_only=_A)
class Options:timeout:Final[timedelta|_B]=_B;progress_interval:Final[timedelta|_B]=_B;warn_unsupported:Final[bool]=_C;sound_class_decorators:Final[bool]=_A;excluded_modules:Final[Collection[str]]=();root_dir:Final[Path]=field(default_factory=Path.cwd);native_edges:Final[bool]=_A;coroutine_edges:Final[bool]=_C;context_sensitivity:Final[ContextSensitivity]=ContextSensitivity.OFF;return_constant_arg_optimization:Final[bool]=_A;variable_rename_optimization:Final[bool]=_A;model_binop_data_flow:Final[bool]=_C;model_mapping_unpacking:Final[bool]=_C;tracked_modules:Final[Collection[str]]=()
MAMBALADE_DEBUG='MAMBALADE_DEBUG'in os.environ or sys.flags.dev_mode
if MAMBALADE_DEBUG:print('Running mambalade with additional debug assertions enabled',file=sys.stderr)
def compute_tracked_modules(vulnerabilities):A=[A[A.index('<')+1:A.index('>')]for A in vulnerabilities if'<'in A and'>'in A];return tuple({B.strip()for A in A for B in(A[1:-1].split(',')if A.startswith('{')else[A])})