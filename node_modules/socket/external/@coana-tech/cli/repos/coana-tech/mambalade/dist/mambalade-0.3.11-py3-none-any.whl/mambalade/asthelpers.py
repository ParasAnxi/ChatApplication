from __future__ import annotations
_C=False
_B=True
_A=None
import ast
from dataclasses import dataclass
from typing import Final,Protocol,TypeAlias,TypeGuard,final
from typing_extensions import override
from.util import Singleton
class _HasLoc(Protocol):lineno:int;col_offset:int;end_lineno:int|_A;end_col_offset:int|_A
def _has_loc(node):return hasattr(node,'lineno')and hasattr(node,'end_lineno')
@dataclass(unsafe_hash=_B)
class ASTLocation:
	lineno:Final[int];col_offset:Final[int];end_lineno:Final[int];end_col_offset:Final[int]
	def __lt__(A,other):B=other;return(A.lineno,A.col_offset)<(B.lineno,B.col_offset)
	def __str__(A):return f"{A.lineno}:{A.col_offset}:{A.end_lineno}:{A.end_col_offset}"
@final
class DummyASTLocation(ASTLocation,Singleton):
	def __init__(A):super().__init__(-1,-1,-1,-1)
	@override
	def __str__(self):return'?:?:?:?'
def loc_ast(node,*,one_indexed_col=_C):
	D=one_indexed_col;A=node
	if _has_loc(A):B=C=A
	elif isinstance(A,ast.comprehension):B=A.target;C=A.ifs[-1]if A.ifs else A.iter
	else:return DummyASTLocation()
	return ASTLocation(B.lineno,B.col_offset+D,C.end_lineno if C.end_lineno is not _A else B.lineno,(C.end_col_offset if C.end_col_offset is not _A else B.col_offset)+D)
def str_ast(node):
	C=node
	match C:
		case ast.FunctionDef(B):A=f"Function({B})"
		case ast.AsyncFunctionDef(B):A=f"AsyncFunction({B})"
		case ast.Lambda():A='Lambda'
		case ast.ClassDef(B):A=f"Class({B})"
		case ast.Attribute(_,D):A=f"Attribute({D})"
		case ast.Name(id):A=f"Name({id})"
		case ast.Module():return'<module>'
		case _:A=type(C).__name__
	return f"{A}:{loc_ast(C)}"
def expr_matches_module_attr(expr,module,name,*,allow_string=_C):
	B=module;A=name
	match expr:
		case ast.Name(id,ctx=ast.Load())if id==A:return _B
		case ast.Attribute(ast.Name(C)|ast.Call(ast.Name('__import__'),[ast.Constant(str(C))],[]),D,ctx=ast.Load())if C==B and D==A:return _B
		case ast.Constant(str(E))if allow_string and E in(A,f"{B}.{A}"):return _B
		case _:return _C
FunctionNode=ast.FunctionDef|ast.AsyncFunctionDef|ast.Lambda
ComprehensionNode=ast.ListComp|ast.SetComp|ast.DictComp|ast.GeneratorExp
def compute_definite_declarations(stmts):
	A=set[str]()
	def C(target,*,del_stmt=_C):
		E=del_stmt
		match target:
			case ast.Name(F,B):
				if not E:A.add(F)
				else:A.discard(F)
			case ast.Subscript(ctx=B)|ast.Attribute(ctx=B):pass
			case ast.List(G,B)|ast.Tuple(G,B):
				for D in G:C(D.value if isinstance(D,ast.Starred)else D,del_stmt=E)
			case _:return
		assert isinstance(B,ast.Store|ast.Del)
	for H in stmts:
		match H:
			case ast.Assign(B):
				for D in B:C(D)
			case ast.AnnAssign(I,_,J)if J is not _A:C(I)
			case ast.Delete(B):
				for D in B:C(D,del_stmt=_B)
			case ast.FunctionDef(E)|ast.AsyncFunctionDef(E)|ast.ClassDef(E):A.add(E)
			case ast.If(_,F,G)if F and G:A|=compute_definite_declarations(F)&compute_definite_declarations(G)
			case _:pass
	return A