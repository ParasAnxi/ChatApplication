from __future__ import annotations
_B='.py'
_A=None
import builtins,importlib.machinery,inspect,os.path,re,sys,traceback,types
from typing import TYPE_CHECKING,Final,TypeGuard,cast,overload
if TYPE_CHECKING:from collections.abc import Mapping,Sequence;from pathlib import Path;from _typeshed import ProfileFunction;from mambalade.infos import ModuleIdentifier;from mambalade.output.call_graph.types import SerializedCallGraph
_stdlib_path=getattr(sys,'_stdlib_dir',_A)or os.path.dirname(os.__file__)
_bytecode_suffixes=tuple(importlib.machinery.BYTECODE_SUFFIXES)
_missing=object()
def _is_path_interesting(file):A=file;return A is not _A and not A.endswith('/site-packages/six.py')and not A.startswith(_stdlib_path)
def _path_from_code(code):
	A=code.co_filename
	if A.endswith(_bytecode_suffixes):A=os.path.splitext(A)[0]+_B
	elif not A.endswith(_B):return
	return A if _is_path_interesting(A)else _A
class _SuppressException:
	__slots__=()
	def __enter__(A):0
	def __exit__(B,C,A,D):
		if A is not _A and isinstance(A,Exception):traceback.print_exception(A);print('The above exception was suppressed during profiling.',file=sys.stderr);return True
_suppress_exception=_SuppressException()
class Profiler:
	def __init__(A,root,module_allowlist=_A,excluded_modules=_A):C=excluded_modules;B=module_allowlist;print('Initializing profiler');A.root=root;A.modules={};A.targets={};A.edges=set[tuple[int,int]]();A._old_import=builtins.__import__;A._old_profile=_A;A._module_allowed=re.compile(f"^(?:{"|".join(map(re.escape,B))})\\b")if B is not _A else _A;A._module_excluded=re.compile(f"^(?:{"|".join(map(re.escape,C))})\\b")if C is not _A else _A;A._sourcefile_to_module_index=dict[str,int|_A]()
	@overload
	def _module_index_from_sourcefile(self,file,*,code):...
	@overload
	def _module_index_from_sourcefile(self,file,*,module):...
	def _module_index_from_sourcefile(B,file,*,code=_A,module=_A):
		D=module;C=file;E=B._sourcefile_to_module_index
		if(G:=E.get(C,_missing))is not _missing:return G
		if code is not _A:D=inspect.getmodule(code,_filename=C)
		if D is _A:A=_A
		else:
			A=D.__name__
			if A=='__main__':A=os.path.basename(C).removesuffix(_B)
			if(H:=B._module_allowed)is not _A and not H.match(A)or(I:=B._module_excluded)is not _A and I.match(A)or A in(__name__,'_distutils_hack','_virtualenv')or A.startswith('__editable__')and A.endswith('_finder'):A=_A
			else:F=os.path.relpath(C,B.root);A=B.modules.setdefault((A,F)if not F.startswith('..')else(A,),len(B.modules))
		E[C]=A;return A
	def _get_target(B,frame):
		A=frame.f_code
		if A.co_name in('<genexpr>','<setcomp>','<dictcomp>','<listcomp>'):return
		if(C:=_path_from_code(A))is _A:return
		if(D:=B._module_index_from_sourcefile(C,code=A))is _A:return
		E=D,A.co_name,A.co_firstlineno;return B.targets.setdefault(E,len(B.targets))
	def __call__(A,frame,event,arg):
		C=event;B=frame
		with _suppress_exception:
			if C=='call'and(B.f_back is not _A and(D:=A._get_target(B))is not _A and(E:=A._get_target(B.f_back))is not _A):A.edges.add((E,D))
			if A._old_profile is not _A:A._old_profile(B,C,arg)
	def _import_hook(A,name,globals=_A,locals=_A,fromlist=(),level=0):
		B=A._old_import(name,globals,locals,fromlist,level)
		with _suppress_exception:
			if isinstance(B,types.ModuleType)and hasattr(B,'__file__')and type((C:=B.__file__))is str and(D:=inspect.currentframe())is not _A and D.f_back is not _A and(E:=A._get_target(D.f_back))is not _A and _is_path_interesting(C)and C.endswith(_B)and(F:=A._module_index_from_sourcefile(C,module=B))is not _A:G=F,'<module>',1;H=A.targets.setdefault(G,len(A.targets));A.edges.add((E,H))
		return B
	def __enter__(A):A._old_import=builtins.__import__;A._old_profile=sys.getprofile();builtins.__import__=A._import_hook;sys.setprofile(A);return A
	def __exit__(A,exc_type,exc_value,traceback):sys.setprofile(A._old_profile);builtins.__import__=A._old_import;return False
	def get_call_graph(A):return{'modules':cast('list[tuple[ModuleIdentifier, str]]',list(A.modules)),'targets':list(A.targets),'edges':list(A.edges)}