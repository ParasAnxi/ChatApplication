from __future__ import annotations
_E='#var-list'
_D=False
_C='#code'
_B=True
_A=None
import ast
from pathlib import Path
from typing import TYPE_CHECKING,Final
from rich.text import Text
from rich.traceback import Traceback
from textual import on
from textual.containers import Horizontal,Vertical
from textual.events import Click
from textual.reactive import reactive
from textual.widgets import Label,ListItem,ListView,Pretty,TextArea
from textual.widgets.text_area import Selection
from mambalade.asthelpers import loc_ast
from mambalade.vars import NodeVar
if TYPE_CHECKING:from textual.app import ComposeResult;from mambalade.infos import ModuleIdentifier;from mambalade.solver import Solver
class ModuleViewer(Horizontal):
	def __init__(A,solver):
		F=solver;A.solver=F;A.a=F.global_state;C={};A.path_to_module=C
		for(B,G)in A.a.modules.items():
			if(J:=G.spec.origin)is _A:continue
			D=Path(J)
			if D in C:A.log(f"Duplicate path: {D} for {B} and {C[D]}")
			C[D]=B
		I={}
		for(B,G)in A.a.modules.items():
			if(K:=G.ast)is _A:continue
			for L in ast.walk(K):I[L]=B
		H={};A.module_to_nodevars=H
		for E in F.all_vars():
			if isinstance(E,NodeVar):
				B=I.get(E.node)
				if B is _A:A.log(f"NodeVar without module: {E}");continue
				H.setdefault(B,[]).append(E)
		for M in H.values():M.sort(key=lambda var:(loc_ast(var.node),str(var.context)))
		super().__init__(id='module-viewer')
	path:reactive[Path|_A]=reactive(_A)
	def compose(A):
		yield TextArea.code_editor('',language='python',soft_wrap=_B,id='code',read_only=_B)
		with Vertical(id='info'):yield ListView(id='var-list');yield ListView(id='token-list')
	class ListVar(ListItem):
		def __init__(A,var):A.var=var;super().__init__(Label(Text(str(var))))
	async def watch_path(B,path):
		A=B.query_one(_C,TextArea)
		if path is _A:A.text='';return
		try:A.text=path.read_text();await B._mount_vars()
		except Exception:B.log(Traceback(theme='github-dark',width=_A));A.text='ERROR'
		else:A.scroll_home(animate=_D)
	async def _mount_vars(A,pos=_A):
		C=pos
		if A.path is _A:return
		def E(var):
			A=loc_ast(var.node)
			if C is _A:return _B
			if A.lineno==-1:return _D
			B,D=C
			if A.lineno<B<A.end_lineno:return _B
			if A.lineno==A.end_lineno:return B==A.lineno and A.col_offset<=D<=A.end_col_offset
			elif A.lineno==B:return A.col_offset<=D
			elif A.end_lineno==B:return D<=A.end_col_offset
			return _D
		F=A.path_to_module[A.path];vars=A.module_to_nodevars[F]
		if C is not _A:
			B=[A for A in vars if E(A)]
			if B:B.reverse();vars=B
		else:B=_A
		D=A.query_one(_E,ListView);D.clear();await D.extend(A.ListVar(B)for B in vars)
		if B:D.index=0
	@on(Click,_C)
	async def handle_code_click(self,event):event.stop();A=self.query_one(_C,TextArea);B,C=A.cursor_location;await self._mount_vars((B+1,C))
	@on(ListView.Highlighted,_E)
	def handle_selected_var(self,event):
		D=event;A=self;B=D.item
		if B is _A:return
		assert isinstance(B,A.ListVar);D.stop();A.log('selected',B.var);C=loc_ast(B.var.node)
		if C.lineno>=1:E=A.query_one(_C,TextArea);E.selection=Selection((C.lineno-1,C.col_offset),(C.end_lineno-1,C.end_col_offset));E.scroll_cursor_visible(animate=_B)
		F=A.query_one('#token-list',ListView);F.clear();G=A.solver.get_tokens(B.var);F.extend(ListItem(Pretty(A))for A in G)