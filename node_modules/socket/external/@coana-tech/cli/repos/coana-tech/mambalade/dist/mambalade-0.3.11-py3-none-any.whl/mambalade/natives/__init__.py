from __future__ import annotations
__all__=['BaseException','Coroutine','Dict','Exception','Generator','List','ModuleToken','Object','Set','Tuple']
from.core import Object
from.dict import Dict
from.exceptions import BaseException,Exception
from.functions import Coroutine,Generator
from.module import ModuleToken
from.sequences import List,Tuple
from.set import Set