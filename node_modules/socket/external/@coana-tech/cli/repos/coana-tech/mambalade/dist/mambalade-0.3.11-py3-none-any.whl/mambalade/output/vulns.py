from __future__ import annotations
import json
from typing import TYPE_CHECKING,Literal
if TYPE_CHECKING:import io;from mambalade.vulns import VulnerabilityResults
def dump_vulnerability_results(res,fp):
	H='column';G='line';F='misses';E='matches';B={E:{},F:{}}
	for(D,(I,C))in res.items():
		if I:assert not isinstance(C,str);B[E][D]={'analysisLevel':'function-level','stacks':[[{'package':B.package,'sourceLocation':{'filename':(A:=B.source_location).filename,'start':{G:A.loc.lineno,H:A.loc.col_offset},'end':{G:A.loc.end_lineno,H:A.loc.end_col_offset}},'confidence':B.confidence}for B in B]for B in C]}
		else:B[F][D]=C
	json.dump(B,fp,indent=2)