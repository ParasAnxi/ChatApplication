from __future__ import annotations
_C=True
_B=False
_A=None
import ast
from dataclasses import dataclass,field
from enum import Enum,auto
from typing import TYPE_CHECKING,Final,Generic,Literal,NamedTuple,NewType,TypeAlias,final
from typing_extensions import TypeVar
from.asthelpers import ComprehensionNode,FunctionNode,compute_definite_declarations,str_ast
from.contexts import Context,EmptyContext
if TYPE_CHECKING:from collections.abc import Collection,Mapping;from importlib.machinery import ModuleSpec;from.calls import ParameterList;from.visitors.analysis import AnalysisVisitor;from.visitors.bindings import DeclInfo,Free
ModuleIdentifier=NewType('ModuleIdentifier',str)
@final
class ModuleKind(Enum):APP=auto();LIBRARY=auto();NATIVE=auto()
@final
@dataclass(slots=_C)
class ModuleInfo:
	spec:Final[ModuleSpec];kind:Final[ModuleKind];excluded:Final[bool]=_B;ast:ast.Module|_A=_A;visitor:AnalysisVisitor|_A=field(default=_A,init=_B)
	@property
	def name(self):return ModuleIdentifier(self.spec.name)
@final
@dataclass(unsafe_hash=_C)
class Native:
	name:Final[str]
	def __str__(A):return f"Native('{A.name}')"
@final
class SynthProp(Enum):DICT_KEYS=auto();DICT_VAL_UNKNOWN=auto();DICT_VAL_ALL=auto();SET_VALUES=auto();SEQ_UNKNOWN=auto();SEQ_ALL=auto();CLASSMETHOD_FUNCTION=auto();STATICMETHOD_FUNCTION=auto();PROPERTY_FGET=auto();PROPERTY_FSET=auto();PROPERTY_FDEL=auto();GENERATOR_ELEMENT=auto();COROUTINE_ELEMENT=auto();WEAKREF_OBJ=auto();CONTEXTMANAGER_FUNCTION=auto();CONTEXTMANAGER_RESULT=auto()
NamespaceNode=ast.ClassDef|FunctionNode|ComprehensionNode
_N=TypeVar('_N',bound=ast.AST,default=ast.AST,covariant=_C)
_N2=TypeVar('_N2',bound=ast.AST)
@final
@dataclass(slots=_C,unsafe_hash=_C)
class QualifiedNode(Generic[_N]):
	node:Final[_N];module:Final[ModuleIdentifier]
	def __str__(A):return f"{A.module}:{str_ast(A.node)}"
	def __repr__(A):return f"QualifiedNode(node={str_ast(A.node)}, module={A.module!r})"
	def replace(A,node):return QualifiedNode(node,A.module)
@final
class NodeSource(NamedTuple):
	namespace:QualifiedNode[FunctionNode|ast.ClassDef];context:Context
	def __str__(A):return f"{A.namespace} @ {A.context}"
CallEdgeSource=NodeSource|ModuleIdentifier
@final
class CallEdgeKind(Enum):NORMAL=auto();IMPORT=auto();NATIVE=auto();ESCAPED=auto();COROUTINE=auto()
CallEdge=tuple[Literal[CallEdgeKind.NORMAL,CallEdgeKind.ESCAPED,CallEdgeKind.COROUTINE],NodeSource]|tuple[Literal[CallEdgeKind.IMPORT],ModuleIdentifier]|tuple[Literal[CallEdgeKind.NATIVE],Native]
CallEdgeTarget=CallEdgeSource|Native
def source_module(source):A=source;return A if isinstance(A,str)else A.namespace.module
_NN=TypeVar('_NN',bound=NamespaceNode,default=NamespaceNode,infer_variance=_C)
@dataclass(slots=_C)
class NamespaceNodeInfo(Generic[_NN]):
	node:Final[QualifiedNode[_NN]];name:Final[str];parent:Final[NamespaceNodeInfo|_A];fully_qualified_name:Final[str];declarations:Mapping[str,DeclInfo]=field(default_factory=lambda d={}:d,init=_B)
	@property
	def parent_fun(self):
		A=self
		while A.parent is not _A:
			if isinstance((A:=A.parent),FunctionInfo):return A
@final
@dataclass(slots=_C)
class ClassInfo(NamespaceNodeInfo[ast.ClassDef]):
	_annotations:Mapping[str,ast.AnnAssign]|_A=field(default=_A,init=_B)
	@property
	def annotations(self):
		A=self
		if A._annotations is _A:
			C=A.node.node;A._annotations={}
			for B in C.body:
				if isinstance(B,ast.AnnAssign)and B.simple:assert isinstance(B.target,ast.Name);A._annotations[B.target.id]=B
		return A._annotations
	_definite_declarations:set[str]|_A=field(default=_A,init=_B)
	@property
	def definite_declarations(self):
		A=self
		if A._definite_declarations is _A:A._definite_declarations=compute_definite_declarations(A.node.node.body)
		return A._definite_declarations
@final
@dataclass(slots=_C)
class FunctionInfo(NamespaceNodeInfo[FunctionNode]):params:Final[ParameterList];returned_constant_params:set[str]|_A=field(default=_A,init=_B);generator:bool=field(default=_B,init=_B);visited:bool=field(default=_B,init=_B);reachable_contexts:Final[set[Context]]=field(default_factory=set,init=_B);free_variables:Final[dict[str,tuple[Free,NamespaceNode]]]=field(default_factory=dict,init=_B)
def reachable_contexts(fun):return(EmptyContext(),)if fun is _A else fun.reachable_contexts