from __future__ import annotations
_A='typing'
import importlib.abc
from importlib.machinery import ModuleSpec
from typing import TYPE_CHECKING,Final,NamedTuple,final
from typing_extensions import override
from mambalade.infos import ModuleIdentifier
from mambalade.natives import Dict,List,Object,Set,Tuple
from mambalade.natives.builtin_functions import builtin_functions
from mambalade.natives.core import Type
from mambalade.natives.exceptions import builtin_exceptions
from mambalade.natives.functions import ClassMethod,StaticMethod
from mambalade.natives.module import ModuleToken
from mambalade.natives.property import Property
from mambalade.tokens import UnknownToken
from mambalade.util import Singleton
from mambalade.vars import PropVar
from.abc import model as abc_model
from.asyncio import model as asyncio_model
from.collections import model as collections_model
from.contextlib import model as contextlib_model
from.copy import model as copy_model
from.dataclasses import model as dataclasses_model
from.enum import model as enum_model
from.functools import model as functools_model
from.importlib import model as importlib_model
from.inspect import model as inspect_model
from.typing import model as typing_model
from.unittest import model as unittest_model
from.weakref import model as weakref_model
if TYPE_CHECKING:import types;from collections.abc import Collection,Mapping,Sequence;from mambalade.solver import Solver;from mambalade.tokens import NativeToken
class NativeModuleSpec(NamedTuple):tokens:Mapping[str,NativeToken];unknowns:Collection[str]=()
_modules={'builtins':NativeModuleSpec({'object':Object,'type':Type,'property':Property,'classmethod':ClassMethod,'staticmethod':StaticMethod,'tuple':Tuple,'list':List,'dict':Dict,'set':Set}|builtin_exceptions|builtin_functions)}
for(name,tokens)in(('asyncio',asyncio_model),(_A,typing_model),('functools',functools_model),('dataclasses',dataclasses_model),('collections',collections_model),('contextlib',contextlib_model),('copy',copy_model),('importlib',importlib_model),('inspect',inspect_model),('abc',abc_model),('enum',enum_model),('unittest',unittest_model),('weakref',weakref_model)):
	mod=__import__(name)
	try:all_names=set(mod.__all__)
	except AttributeError:all_names={A for A in dir(mod)if not A.startswith('_')}
	if name==_A:all_names.add('TypeVarTuple')
	_modules[name]=NativeModuleSpec(tokens,set(all_names)-tokens.keys())
@final
class NativeModuleImporter(importlib.abc.MetaPathFinder,importlib.abc.Loader,Singleton):
	@override
	def find_spec(self,fullname,path,target=None):
		A=fullname
		if(B:=_modules.get(A))is None:return
		return ModuleSpec(A,self,is_package=False,origin='native',loader_state=B)
	@staticmethod
	def setup_module(spec,solver):
		C=solver;A=spec;assert isinstance(A.loader,NativeModuleImporter);D=A.loader_state;E=ModuleToken(ModuleIdentifier(A.name))
		for(B,F)in D.tokens.items():C.add_token_constraint(F,PropVar(E,B))
		G=UnknownToken()
		for B in D.unknowns:C.add_token_constraint(G,PropVar(E,B))