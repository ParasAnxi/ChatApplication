from __future__ import annotations
_A='__call__'
import ast,logging
from dataclasses import replace
from typing import TYPE_CHECKING
from mambalade.calls import AbstractArgs
from mambalade.infos import SynthProp
from mambalade.listeners import Listener,ListenerKey
from mambalade.natives import Object
from mambalade.natives.builtin_functions import noop
from mambalade.natives.functions import BoundMethodToken
from mambalade.natives.helpers import NativeType,native_function,native_method,native_type
from mambalade.tokens import AccessPathToken,ImmutableToken,NativeToken,ObjectToken,Token,UnknownToken
from mambalade.vars import ConstraintVar,PropVar
if TYPE_CHECKING:from collections.abc import Mapping;from mambalade.calls import CallData;from mambalade.operations import Operations
logger=logging.getLogger(__name__)
@native_type(Object,tname='contextlib.ContextDecorator')
class ContextDecorator(NativeType):
	@native_method(_A,spec='lambda self, func, /: 2')
	@staticmethod
	def call(op,d):
		A,B=d.args.args
		if not isinstance(A,ImmutableToken)or ContextDecorator not in A.typ.mro:logger.debug('Ignoring ContextDecorator.__call__ with unexpected self %s',A);return
		if isinstance(B,Token|ConstraintVar):op.return_value(d,B)
def build_contextmanager(is_async):
	A='async'if is_async else''
	@native_function(f"contextlib.{A}contextmanager",spec='lambda func: 0')
	def B(op,d):
		B=op
		if d.args.args:D=d.args.args[0]
		elif d.args.unpack_iter is not None:B.a.warn_unsupported(d.callnode,f"Iterable unpacking in contextlib.{A}contextmanager");return
		elif not d.args.kwargs:return
		else:
			for(F,D)in d.args.kwargs:
				if F=='func':break
			else:
				if any(A is None for(A,B)in d.args.kwargs):B.a.warn_unsupported(d.callnode,f"Mapping unpacking in contextlib.{A}contextmanager")
				return
		if not isinstance(D,Token|ConstraintVar):logger.debug('Ignoring contextlib.%scontextmanager call with non-object function %s',A,D);return
		E=C.new_instance(B,d);B.inclusion_constraint(D,PropVar(E,SynthProp.CONTEXTMANAGER_FUNCTION));B.return_value(d,E)
	@native_type(Object,tname=f"contextlib._{A.title()}ContextManagerHelper")
	class C(NativeType):
		__new__=noop
		@native_method(_A,spec='lambda self, /, *args, **kwargs: 1')
		@staticmethod
		def call(op,d):
			if not isinstance((B:=d.args.args[0]),ImmutableToken)or B.typ is not C:logger.debug('Ignoring %scontextmanager.__call__ with unexpected self %s',A,B);return
			D=E.new_instance(op,d);op.return_value(d,D);F=replace(d,args=AbstractArgs.empty,res=PropVar(D,SynthProp.CONTEXTMANAGER_RESULT),parent=ListenerKey(Listener.NATIVE_CONTEXTMANAGER__CALL__GENERATOR,parent=d.parent))
			def G(gt):op.invoke_special_method(gt,f"__{A[:1]}next__",F)
			op.invoke_object(PropVar(B,SynthProp.CONTEXTMANAGER_FUNCTION),replace(d,args=d.args.shift(),res=G,parent=ListenerKey(Listener.NATIVE_CONTEXTMANAGER__CALL__INVOKE,parent=d.parent)))
		@native_method('__get__',spec='lambda self, instance, owner=None, /: 2')
		@staticmethod
		def get(op,d):
			B,D,*F=d.args.args
			if not isinstance(B,ImmutableToken)or B.typ is not C:logger.debug('Ignoring %scontextmanager.__get__ with unexpected self %s',A,B);return
			match D:
				case ObjectToken():E=C.known_slots[_A];op.return_value(d,BoundMethodToken(BoundMethodToken(E,B),D))
				case None|ConstraintVar():op.return_value(d,B)
				case UnknownToken():op.return_value(d,D)
				case AccessPathToken():pass
				case str()|int()|ast.Slice():pass
	D=f"__{A[:1]}enter__"
	@native_type(ContextDecorator,Object,tname=f"contextlib._{A.title()}GeneratorContextManager")
	class E(NativeType):
		__new__=noop
		@native_method(D,spec='lambda self, /: 1')
		@staticmethod
		def enter(op,d):
			B=d.args.args[0]
			if not isinstance(B,ImmutableToken)or E is not B.typ:logger.debug('Ignoring %scontextmanager.%s call with non-contextmanager self %s',A,D,B);return
			op.return_value(d,PropVar(B,SynthProp.CONTEXTMANAGER_RESULT))
	return B
model={'contextmanager':build_contextmanager(False),'asynccontextmanager':build_contextmanager(True)}