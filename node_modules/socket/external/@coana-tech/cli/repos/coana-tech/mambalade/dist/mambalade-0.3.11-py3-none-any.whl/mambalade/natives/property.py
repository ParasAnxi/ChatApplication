from __future__ import annotations
import logging
from dataclasses import replace
from typing import TYPE_CHECKING,Literal
from mambalade.calls import AbstractArgs
from mambalade.infos import SynthProp
from mambalade.listeners import Listener,ListenerKey
from mambalade.tokens import ObjectToken,Token
from mambalade.vars import ConstraintVar,PropVar
from.core import Object
from.helpers import MethodSlotDef,NativeType,native_method,native_type
if TYPE_CHECKING:from mambalade.calls import CallData;from mambalade.operations import Operations
logger=logging.getLogger(__name__)
def _make_property_decorator_helper(name,prop):
	B=name
	def A(op,d):
		C=d.args
		if C.unpack_iter:op.a.warn_unsupported(d.callnode,f"property.{B} with *args")
		if len(C.args)!=2:logger.debug('Discarding invalid call to property.%s with %d arguments',B,len(C.args));return
		A,D=C.args
		if isinstance(A,ConstraintVar):op.a.warn_unsupported(d.callnode,f"property.{B} on non-constant token");return
		assert isinstance(A,ObjectToken)and Property in A.typ.mro
		if isinstance(D,Token|ConstraintVar):op.inclusion_constraint(D,PropVar(A,prop))
		op.return_value(d,A)
	return native_method(B)(A)
@native_type(Object)
class Property(NativeType):
	@native_method('__init__',spec='lambda self, /, fget=None, fset=None, fdel=None, doc=None: 1')
	@staticmethod
	def init(op,d):
		C=d.args;B,*E=C.args
		if not isinstance(B,ObjectToken):op.a.warn_unsupported(d.callnode,'property.__init__ with non-constant self');return
		if Property not in B.typ.mro:logger.debug('Discarding property.__init__ with non-property self');return
		for(F,A)in zip(('GET','SET','DEL'),E,strict=False):
			if isinstance(A,Token|ConstraintVar):op.inclusion_constraint(A,PropVar(B,SynthProp[f"PROPERTY_F{F}"]))
		if C.kwargs:
			for(D,A)in C.kwargs:
				if D is None:op.a.warn_unsupported(d.callnode,'property.__init__ with **kwargs');continue
				elif D!='doc'and isinstance(A,Token|ConstraintVar):op.inclusion_constraint(A,PropVar(B,SynthProp[f"PROPERTY_{D.upper()}"]))
	@native_method('__get__',spec='lambda self, obj, type=None, /: 2')
	@staticmethod
	def get(op,d):
		C=d.args;A,B,*D=C.args
		if isinstance(B,ConstraintVar):op.a.warn_unsupported(d.callnode,'property.__get__ on non-constant token');return
		assert isinstance(A,ObjectToken)and Property in A.typ.mro
		match B:
			case ObjectToken():op.invoke_object(PropVar(A,SynthProp.PROPERTY_FGET),replace(d,args=AbstractArgs.seq(B),parent=ListenerKey(Listener.NATIVE_PROPERTY__GET__,parent=d.parent)))
			case _ if B is None:op.return_value(d,A)
			case _:raise NotImplementedError(f"Unsupported arguments for property.__get__: {C.args[1:]}")
	@native_method('__set__',spec='lambda self, obj, value, /: 3')
	@staticmethod
	def set(op,d):
		A,B,C=d.args.args
		if not isinstance(A,ObjectToken)or Property not in A.typ.mro:logger.debug('Discarding property.__set__ with non-property self');return
		if not isinstance(B,ObjectToken):op.a.warn_unsupported(d.callnode,'property.__set__ on non-constant token');return
		op.invoke_object(PropVar(A,SynthProp.PROPERTY_FSET),replace(d,args=AbstractArgs.seq(B,C),parent=ListenerKey(Listener.NATIVE_PROPERTY__SET__,parent=d.parent)))
	@native_method('__delete__',spec='lambda self, obj, /: 2')
	@staticmethod
	def delete(op,d):op.a.warn_unsupported(d.callnode,'property.__delete__')
	getter=_make_property_decorator_helper('getter',SynthProp.PROPERTY_FGET);setter=_make_property_decorator_helper('setter',SynthProp.PROPERTY_FSET);deleter=_make_property_decorator_helper('deleter',SynthProp.PROPERTY_FDEL)