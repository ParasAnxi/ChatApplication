from __future__ import annotations
_A='lambda self, /: 1'
from typing import TYPE_CHECKING,Final,final
from typing_extensions import override
from mambalade.options import MAMBALADE_DEBUG
from mambalade.tokens import ObjectToken
from mambalade.util import CacheHashMixin
from.builtin_functions import noop
from.core import Object
from.helpers import NativeType,native_method,native_type
if TYPE_CHECKING:from mambalade.calls import CallData;from mambalade.infos import QualifiedNode;from mambalade.operations import Operations;from mambalade.vars import ConstraintVar
@native_type(Object)
class NativeIterator(NativeType):
	__new__=noop
	@native_method('__iter__',spec=_A)
	@staticmethod
	def iter(op,d):
		match d.args.args[0]:
			case IteratorToken()as A:op.return_value(d,A)
			case _:raise AssertionError('Unexpected token in NativeIterator.__iter__')
	@native_method('__next__',spec=_A)
	@staticmethod
	def next(op,d):
		match d.args.args[0]:
			case IteratorToken(_,A):op.return_value(d,A)
			case _:raise AssertionError('Unexpected token in NativeIterator.__next__')
@final
class IteratorToken(ObjectToken,CacheHashMixin):
	typ=NativeIterator;immutable=True;__match_args__='site','value'
	def __init__(A,site,value):super().__init__();assert not isinstance(site,IteratorToken);A.site=site;A.value=value
	def __str__(A):return f"IteratorToken({A.site})"
	def __eq__(B,A):return isinstance(A,IteratorToken)and B.site==A.site
	if MAMBALADE_DEBUG:
		def __eq__(B,A):
			if not isinstance(A,IteratorToken)or B.site!=A.site:return False
			assert B.value==A.value;return True
	@override
	def _compute_hash(self):return hash((type(self),self.site))
	@override
	def _lookup_attr(self,attr):return None,False