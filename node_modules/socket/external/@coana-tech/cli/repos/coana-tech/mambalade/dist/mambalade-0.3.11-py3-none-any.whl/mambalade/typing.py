from __future__ import annotations
from typing import TYPE_CHECKING,TypeVar
if TYPE_CHECKING:
	from abc import ABCMeta
	class TypeABC(metaclass=ABCMeta):__slots__=()
else:
	class TypeABC:__slots__=()
_T=TypeVar('_T')
def checked_cast(typ,value):A=value;assert isinstance(A,typ);return A