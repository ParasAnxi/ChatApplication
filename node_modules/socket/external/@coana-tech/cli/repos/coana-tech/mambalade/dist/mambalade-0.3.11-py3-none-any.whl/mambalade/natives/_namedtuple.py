from __future__ import annotations
_H='typing.NamedTuple'
_G='QualifiedNode[ast.Call]'
_F='lambda cls, /, *args, **kwargs: 1'
_E='__new__'
_D='collections.namedtuple'
_C=True
_B=False
_A=None
import ast,keyword,logging
from dataclasses import replace
from typing import TYPE_CHECKING,Final,Literal,TypeGuard,cast,final
from typing_extensions import override
from mambalade.calls import MatchResult,Param,ParameterList,may_args_match_params
from mambalade.contexts import Context,EmptyContext
from mambalade.infos import ClassInfo,Native,QualifiedNode,SynthProp
from mambalade.listeners import Listener,ListenerKey
from mambalade.options import MAMBALADE_DEBUG
from mambalade.tokens import ImmutableToken,NativeToken,ObjectToken,Token,TypeToken,UnknownToken,class_lookup_attr
from mambalade.util import simple_cache
from mambalade.vars import ConstraintVar,DictKeyVar,NamespaceVar,PropVar,SeqIndexVar,constraintvar
from.builtin_functions import noop
from.core import Object,Type
from.core_tokens import ClassMethodToken,NativeTypeToken
from.dict import Dict
from.helpers import NativeType,native_function,native_method,native_type
from.sequences import Tuple
if TYPE_CHECKING:from collections.abc import Set;from mambalade.calls import CallData;from mambalade.operations import Operations;from mambalade.solver import Solver
logger=logging.getLogger(__name__)
@native_type(Object)
@final
class _Tuplegetter(NativeType):
	__new__=noop
	@native_method('__get__',spec='lambda self, instance, owner=None: 2')
	@staticmethod
	def get(op,d):
		if not isinstance((B:=d.args.args[0]),TuplegetterToken):logger.debug('Ignoring _Tuplegetter.__get__ for non-tuplegetter %s',B);return
		if not isinstance((A:=d.args.args[1]),ObjectToken):logger.debug('Ignoring _Tuplegetter.__get__ for non-constant instance %s',A);return
		if Tuple not in A.typ.mro:logger.debug('Ignoring _Tuplegetter.__get__ for non-tuple %s',A);return
		op.return_value(d,SeqIndexVar(A,B.index))
@final
class TuplegetterToken(NativeToken):
	typ=_Tuplegetter
	@override
	def __init__(self,index):A=index;super().__init__(Native(f"_tuplegetter_{A}"));self.index=A
	@override
	def _lookup_attr(A,B):return _A,_B
_tuplegetter=simple_cache(TuplegetterToken)
@final
class NamedTupleTypeToken(TypeToken):
	typ=Type
	def __init__(A,node_or_info,name,fields,defaults,generic=_A):
		F=generic;E=defaults;D=fields;C=node_or_info;A.mro=(A,Tuple,Object)if F is _A else(A,Tuple,F,Object)
		if isinstance(C,ClassInfo):B=C;G=B.node
		else:B=_A;G=C
		A.user_defined=B and B.node;A.immutable=B is _A;A.node=G;A.info=B;A.name=name if name is not _A else'?';A.fields=D;A.defaults=E;H=len(D);J=len(E)if isinstance(E,tuple)else H;I=[Param(B,A,has_default=J>=H-A)for(A,B)in enumerate(D)];A.new_params=ParameterList(I,{A.name:A for A in I})
	@override
	def __str__(self):return f"NamedTupleTypeToken({self.name}, {self.node})"
	@override
	def __eq__(self,other):A=other;return isinstance(A,NamedTupleTypeToken)and self.node==A.node
	if MAMBALADE_DEBUG:
		orig_eq=__eq__
		def __eq__(A,other):
			B=other
			if not A.orig_eq(B):return _B
			assert(A.name,A.fields,A.defaults)==(B.name,B.fields,B.defaults);return _C
	@override
	def __hash__(self):return hash((type(self),self.node))
	@override
	def new_instance(self,op,d):return ImmutableToken(d.callnode,self)
	@override
	def _lookup_attr(A,B):
		if(D:=type(A)._cls_fields.get(B))is not _A:return D,_C
		if(C:=A.new_params.param_by_name.get(B))is not _A:assert C.index is not _A;return _tuplegetter(C.index),_C
		if B in('_fields','_field_defaults'):return _A,_C
		if A.info is _A:return _A,_B
		return class_lookup_attr(A,A.info,B)
	@native_type(tname=_D)
	class _NTHelper(NativeType):
		@native_method(_E,spec=_F)
		@staticmethod
		def new(op,d):
			A=op;C=d.args
			if not isinstance((D:=C.args[0]),Token|ConstraintVar):logger.debug('Ignoring namedtuple.__new__ for non-token %s',D);return
			B=C.shift()
			def E(ct):
				C=ct
				if isinstance(C,UnknownToken):A.return_value(d,C);return
				if not isinstance(C,TypeToken):A.a.warn_unsupported(d.callnode,f"Non-type token in namedtuple.__new__: {type(C)}");return
				if(E:=_get_nt_base(C))is _A:logger.debug('Ignoring namedtuple.__new__ for non-namedtuple %s',C);return
				match may_args_match_params(B,E.new_params):
					case MatchResult(K,F,L):pass
					case M,N:
						if logger.isEnabledFor(logging.DEBUG):logger.debug('Incompatible arguments for namedtuple at %s (fields: %s): %s',d.callnode,E.fields,M%N)
						return
				D=C.new_instance(A,d);A.return_value(d,D)
				for(O,G)in enumerate(B.args):
					if isinstance(G,Token|ConstraintVar):A.inclusion_constraint(G,SeqIndexVar(D,O))
				if len(B.args)<F and B.unpack_iter is not _A:A.unpack_iterable_into_vars([SeqIndexVar(D,A)for A in range(len(B.args),F)],_A,B.unpack_iter,d.callnode,d.caller,ListenerKey(Listener.NATIVE_NAMEDTUPLE__NEW__UNPACK,token=C,parent=d.parent))
				if B.kwargs is not _A:
					if L:A.a.warn_unsupported(d.callnode,'Mapping unpacking in namedtuple.__new__')
					P=E.new_params.param_by_name
					for(H,I)in B.kwargs:
						if H is _A:continue
						if isinstance(I,Token|ConstraintVar):J=P[H].index;assert J is not _A;A.inclusion_constraint(I,SeqIndexVar(D,J))
				_nt_assign_defaults(A.solver,D,E,K)
			A.forall_constraint_uncached(D,ListenerKey(Listener.NATIVE_NAMEDTUPLE__NEW__,parent=d.parent),E)
		@ClassMethodToken
		@native_function('namedtuple._make',spec='lambda cls, /, iterable: 1')
		@staticmethod
		def _make(op,d):
			A=op;B=d.args.args[0]
			match B:
				case TypeToken():pass
				case UnknownToken():A.return_value(d,B);return
				case _:logger.debug('Ignoring namedtuple._make for non-constant token %s',B);return
			if(E:=_get_nt_base(B))is _A:logger.debug('Ignoring namedtuple._make for non-namedtuple %s',B);return
			if len(d.args.args)==2:C=d.args.args[1]
			elif d.args.unpack_iter is not _A:A.a.warn_unsupported(d.callnode,'Iterable unpacking in namedtuple._make');return
			else:
				assert d.args.kwargs
				for(F,G)in d.args.kwargs:
					if F is _A:A.a.warn_unsupported(d.callnode,'namedtuple._make with mapping unpacking');return
					elif F=='iterable':C=G;break
				else:raise AssertionError('No iterable argument in namedtuple._make')
			D=B.new_instance(A,d);A.return_value(d,D);_nt_assign_defaults(A.solver,D,E,_A)
			if isinstance(C,Token|ConstraintVar):A.unpack_iterable_into_vars([SeqIndexVar(D,A)for A in range(len(E.fields))],_A,C,d.callnode,d.caller,ListenerKey(Listener.NATIVE_NAMEDTUPLE_MAKE_UNPACK,parent=d.parent))
		@native_method('_replace',spec='lambda self, /, **kwargs: 1')
		@staticmethod
		def replace(op,d):
			B=op;A=d.args.args[0]
			match A:
				case ObjectToken():pass
				case UnknownToken():B.return_value(d,A);return
				case _:logger.debug('Ignoring namedtuple._replace for non-constant self %s',A);return
			if(D:=_get_nt_base(A.typ))is _A:logger.debug('Ignoring namedtuple._replace for non-namedtuple %s',A);return
			E=A.typ.new_instance(B,d);vars=[SeqIndexVar(A,B)for B in range(len(D.fields))]
			for(C,F)in d.args.kwargs or():
				if C is _A:B.a.warn_unsupported(d.callnode,'Mapping unpacking in namedtuple._replace');continue
				if(G:=D.new_params.param_by_name.get(C))is _A:logger.debug("Ignoring namedtuple._replace on %s due to unknown field '%s'",A,C);return
				assert G.index is not _A;vars[G.index]=F if isinstance(F,Token|ConstraintVar)else _A
			B.return_value(d,E)
			for(H,I)in enumerate(vars):B.inclusion_constraint(I,SeqIndexVar(E,H))
		@native_method('_asdict',spec='lambda self, /: 1')
		@staticmethod
		def asdict(op,d):
			A=d.args.args[0]
			if not isinstance(A,ObjectToken):logger.debug('Ignoring namedtuple._asdict for non-constant self %s',A);return
			if(B:=_get_nt_base(A.typ))is _A:logger.debug('Ignoring namedtuple._asdict for non-namedtuple %s',A);return
			op.return_value(d,(C:=Dict.new_instance(op,d)))
			for(D,E)in enumerate(B.fields):op.solver.add_subset_constraint(SeqIndexVar(A,D),DictKeyVar(C,E))
	_cls_fields:Final=_NTHelper.known_slots;del _NTHelper
def _get_nt_base(cls):
	for A in cls.mro:
		if isinstance(A,NamedTupleTypeToken):return A
def _nt_assign_defaults(solver,nt,nt_base,param_filled):
	C=param_filled;A=nt_base
	if(E:=len(A.defaults)if isinstance(A.defaults,tuple)else len(A.fields)):
		for D in range(E):
			B=A.new_params.params[~D];assert B.has_default and B.index is not _A
			if C is _A or B.name not in C:F=A.defaults[~D]if isinstance(A.defaults,tuple)else A.defaults;solver.add_subset_constraint(F,SeqIndexVar(nt,B.index))
def _check_nt_args(func,op,d):
	B=func
	if d.args.unpack_iter is not _A:return _imprecise_namedtuple(f"Iterable unpacking in {B}",op,d)
	match d.callnode.node:
		case ast.Call(_,A,C):pass
		case _:return _imprecise_namedtuple(f"{B} called from non-call node",op,d)
	if len(A)!=len(d.args.args)or len(C)!=len(d.args.kwargs or()):return _imprecise_namedtuple(f"Indirection in call to {B}",op,d)
	D=A[0]if len(A)>=1 else _A;return D,A,C
@native_type(Tuple,Object,tname='collections._namedtuple_imprecise',unsupported_methods='_make _asdict _replace'.split())
class _ImpreciseNamedTuple(NativeType):
	@native_method(_E,spec=_F)
	@staticmethod
	def new(op,d):
		A=op;B=d.args;C,*G=B.args
		if not isinstance(C,Token|ConstraintVar):logger.debug('Ignoring _namedtuple_imprecise.__new__ for non-token %s',C);return
		def D(ct):
			if not isinstance(ct,TypeToken)or _ImpreciseNamedTuple not in ct.mro:logger.debug('Ignoring _namedtuple_imprecise.__new__ for non-namedtuple %s',ct);return
			C=ct.new_instance(A,d)
			for(H,D)in enumerate(G):
				if isinstance(D,Token|ConstraintVar):A.inclusion_constraint(D,SeqIndexVar(C,H))
			E=PropVar(C,SynthProp.SEQ_UNKNOWN)
			if B.unpack_iter is not _A:I=ListenerKey(Listener.NATIVE_NAMEDTUPLE__NEW__,token=C,parent=d.parent);A.unpack_iterable_into(B.unpack_iter,replace(d,res=E,parent=I))
			if B.kwargs:
				for(J,F)in B.kwargs:
					if J is _A:A.a.warn_unsupported(d.callnode,'Mapping unpacking in _namedtuple_imprecise.__new__');continue
					if isinstance(F,Token|ConstraintVar):A.inclusion_constraint(F,E)
			A.return_value(d,C);A.return_value(d,UnknownToken())
		A.forall_constraint_uncached(C,ListenerKey(Listener.NATIVE_NAMEDTUPLE__NEW__,parent=d.parent),D)
def _imprecise_namedtuple(msg,op,d):op.a.warn_unsupported(d.callnode,msg);op.return_value(d,_ImpreciseNamedTuple)
@final
@constraintvar
class NamedTupleDefaultVar(ConstraintVar):
	node:Final[QualifiedNode[ast.Call]];index:Final[int]
	def __str__(A):return f"NamedTupleDefaultVar[{A.node}][{A.index}]"
@native_function(_D,spec='lambda typename, field_names, *, rename=False, defaults=None, module=None: 0')
def namedtuple(op,d):
	S='collections.namedtuple with non-constant field names';B=op
	if(T:=_check_nt_args(_D,B,d))is _A:return
	J,K,U=T;L=K[1]if len(K)>=2 else _A;I=_A;M=_B
	for N in U:
		match(N.arg,N.value):
			case'rename',ast.Constant(bool(A)):M=A
			case None,_:B.a.warn_unsupported(d.callnode,'Mapping unpacking in collections.namedtuple')
			case'typename',A:J=A
			case'field_names',A:L=A
			case'defaults',A:I=A
			case'module',_:pass
			case _:B.a.warn_unsupported(d.callnode,'Unknown keyword argument in collections.namedtuple')
	match J:
		case ast.Constant(str(A)):O=A
		case _:O=_A
	match L:
		case ast.Constant(str(A)):E=A.replace(',',' ').split()
		case ast.Tuple(C)|ast.List(C):
			E=[]
			for V in C:
				match V:
					case ast.Constant(A):E.append(str(A))
					case _:return _imprecise_namedtuple(S,B,d)
		case _:return _imprecise_namedtuple(S,B,d)
	G=cast(_G,d.callnode)
	if I is _A:D=()
	else:
		assert d.args.kwargs is not _A;H=next(B for(A,B)in d.args.kwargs if A=='defaults');P=ListenerKey(Listener.NATIVE_NAMEDTUPLE_DEFAULTS_UNPACK,node_w_context=(G.node,EmptyContext()))
		match I:
			case ast.Tuple(C)|ast.List(C)if not any(isinstance(A,ast.Starred)for A in C):
				D=tuple(NamedTupleDefaultVar(G,A)if not isinstance(B,ast.Constant)else _A for(A,B)in enumerate(C))
				if any(A is not _A for A in D):assert isinstance(H,Token|ConstraintVar);B.unpack_iterable_into_vars(D,_A,H,d.callnode,d.caller,P)
			case _:
				D=NamedTupleDefaultVar(G,0)
				if isinstance(H,Token|ConstraintVar):B.unpack_iterable_into(H,replace(d,res=D,parent=P))
	if M:
		Q=set()
		for(R,F)in enumerate(E):
			if not F.isidentifier()or keyword.iskeyword(F)or F.startswith('_')or F in Q:E[R]=f"_{R}"
			Q.add(F)
	B.return_value(d,NamedTupleTypeToken(G,O,tuple(E),D))
@native_function(_H,spec='lambda typename, fields=None, /, **kwargs: 0')
def NamedTuple(op,d):
	G='typing.NamedTuple with non-constant fields';A=op
	if(H:=_check_nt_args(_H,A,d))is _A:return
	I,C,J=H
	if len(C)>=2:
		match C[1]:
			case ast.Tuple(D)|ast.List(D):
				B=[]
				for K in D:
					match K:
						case ast.Tuple([ast.Constant(L),_]):B.append(str(L))
						case _:return _imprecise_namedtuple(G,A,d)
			case _:return _imprecise_namedtuple(G,A,d)
	else:
		B=[]
		for E in J:
			if E.arg is _A:return _imprecise_namedtuple('typing.NamedTuple with mapping unpacking',A,d)
			B.append(E.arg)
	match I:
		case ast.Constant(str(M)):F=M
		case _:F=_A
	N=cast(_G,d.callnode);A.return_value(d,NamedTupleTypeToken(N,F,tuple(B),()))
def make_typing_NamedTuple_subclass(solver,cnode,bases,info,context):
	F=context;E=solver;A=cnode;G=_A
	for B in bases:
		match B:
			case NativeTypeToken(Native('typing.Generic')):G=B
			case _:logger.warning('Discarding NamedTuple subclass due to unexpected base: %s',B);return
	C=[];H=[]
	for(I,K)in E.global_state.class_info[A.node].annotations.items():
		C.append(I)
		if K.value is not _A:H.append(NamespaceVar(A.node,F,I))
	J=NamedTupleTypeToken(info,A.node.name,tuple(C),tuple(H),G);L=set(C)
	for D in info.declarations:
		if D not in L:E.add_subset_constraint(NamespaceVar(A.node,F,D),PropVar(J,D))
	return J