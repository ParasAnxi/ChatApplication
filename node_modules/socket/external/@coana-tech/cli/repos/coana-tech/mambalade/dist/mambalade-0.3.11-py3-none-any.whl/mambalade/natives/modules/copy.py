from __future__ import annotations
_A='deepcopy'
from dataclasses import replace
from typing import TYPE_CHECKING,Final,Literal,assert_type
from mambalade.calls import AbstractArgs
from mambalade.listeners import Listener,ListenerKey
from mambalade.natives.core import Type
from mambalade.natives.dict import Dict
from mambalade.natives.functions import BoundMethod,Function
from mambalade.natives.helpers import native_function
from mambalade.natives.modules.weakref import ReferenceType
from mambalade.natives.property import Property
from mambalade.natives.sequences import List,Tuple
from mambalade.natives.set import Set as SetType
from mambalade.token_utils import type_has_attr
from mambalade.tokens import AccessPathToken,ObjectToken,Token,TypeToken,UnknownToken
from mambalade.util import TVL
from mambalade.vars import ConstraintVar
if TYPE_CHECKING:from collections.abc import Mapping,Set;from mambalade.calls import CallData;from mambalade.natives.core_tokens import NativeFunctionToken;from mambalade.operations import Operations
_copy_noop=frozenset((Tuple,Type,Property,Function,ReferenceType,List,Dict,SetType))
_deepcopy_noop=_copy_noop|{BoundMethod}
def _copy(op,d,impl,noops,args,copy_key,dunder_key):
	B=impl;A=op
	if not d.args.args:A.a.warn_unsupported(d.callnode,f"copy.{B} with non-positional args");return
	C=d.args.args[0]
	if not isinstance(C,Token|ConstraintVar):return
	def D(t):
		if not isinstance(t,ObjectToken):assert_type(t,UnknownToken|AccessPathToken);A.return_value(d,t);return
		if t.typ in noops or Type in t.typ.mro:A.return_value(d,t);return
		if(C:=type_has_attr(t.typ,f"__{B}__"))is not TVL.FALSE:D=replace(d,args=args,parent=ListenerKey(dunder_key,parent=d.parent));A.invoke_special_method(t,f"__{B}__",D)
		if C is not TVL.TRUE:
			if type_has_attr(t.typ,'__reduce__')is not TVL.FALSE or type_has_attr(t.typ,'__reduce_ex__')is not TVL.FALSE:A.a.warn_unsupported(d.callnode,f"copy.{B} with __reduce__ or __reduce_ex__")
			A.return_value(d,t)
	A.forall_constraint_uncached(C,ListenerKey(copy_key,parent=d.parent),D)
@native_function('copy.copy',spec='lambda x: 0')
def copy(op,d):_copy(op,d,'copy',_copy_noop,AbstractArgs.empty,Listener.NATIVE_COPY_COPY,Listener.NATIVE_COPY__COPY__)
@native_function('copy.deepcopy',spec='lambda x, memo=None: 0')
def deepcopy(op,d):_copy(op,d,_A,_deepcopy_noop,AbstractArgs.seq(UnknownToken()),Listener.NATIVE_COPY_DEEPCOPY,Listener.NATIVE_COPY__DEEPCOPY__)
model={'copy':copy,_A:deepcopy}