from __future__ import annotations
_A=None
from dataclasses import dataclass
from typing import TYPE_CHECKING,Final,TypeAlias,final
from.options import MAMBALADE_DEBUG
from.util import Singleton
if TYPE_CHECKING:from.infos import QualifiedNode
@final
class EmptyContext(Singleton):
	__slots__=()
	def __str__(A):return'⊤'
@final
@dataclass(unsafe_hash=True)
class CompoundContext:
	callnode:Final[QualifiedNode|_A]=_A;decorator_node:Final[QualifiedNode|_A]=_A;decorator_context:Final[CompoundContext|_A]=_A;constant_params:Final[tuple[tuple[str,str],...]]=()
	if MAMBALADE_DEBUG:
		def __post_init__(A):assert A.constant_params==tuple(sorted(A.constant_params))
	def __str__(A):
		B=[]
		if A.decorator_context is not _A:B.append(str(A.decorator_context)+':Wrapper')
		if A.decorator_node is not _A:B.append(f"Decorator[{A.decorator_node}]")
		if A.callnode is not _A and A.callnode!=A.decorator_node:B.append(f"[{A.callnode}]")
		if A.constant_params:B.append(f"[{", ".join(f"{A}={B}"for(A,B)in A.constant_params)}]")
		assert B;return'.'.join(B)
Context=EmptyContext|CompoundContext