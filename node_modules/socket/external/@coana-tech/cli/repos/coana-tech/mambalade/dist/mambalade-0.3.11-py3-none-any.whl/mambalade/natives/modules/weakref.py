from __future__ import annotations
import logging
from dataclasses import replace
from typing import TYPE_CHECKING
from mambalade.calls import AbstractArgs
from mambalade.infos import SynthProp
from mambalade.listeners import Listener,ListenerKey
from mambalade.natives import Dict,Object,Set
from mambalade.natives.helpers import NativeType,generic_class_getitem,native_function,native_method,native_type
from mambalade.tokens import ObjectToken,Token
from mambalade.vars import ConstraintVar,PropVar
if TYPE_CHECKING:from collections.abc import Mapping;from mambalade.calls import CallData;from mambalade.operations import Operations;from mambalade.tokens import NativeToken
logger=logging.getLogger(__name__)
@native_type(Object,tname='weakref.ReferenceType')
class ReferenceType(NativeType):
	__class_getitem__=generic_class_getitem
	@native_method('__init__',spec='lambda self, obj, callback=None, /: 2')
	@staticmethod
	def init(op,d):
		A,B,*C=d.args.args
		if not isinstance(A,ObjectToken)or ReferenceType not in A.typ.mro:logger.debug('Discarding call to weakref.ReferenceType.__init__ with non-ref object');return
		if isinstance(B,Token|ConstraintVar):op.inclusion_constraint(B,PropVar(A,SynthProp.WEAKREF_OBJ))
		if C and isinstance((D:=C[0]),Token|ConstraintVar):op.inclusion_constraint(D,PropVar(A,'__callback__'));op.invoke_object(D,replace(d,args=AbstractArgs.seq(A),res=None,parent=ListenerKey(Listener.NATIVE_WEAKREF_CALLBACK,(d.callnode.node,d.context),token=A)))
	@native_method('__call__',spec='lambda self, /: 1')
	@staticmethod
	def call(op,d):
		if not isinstance((A:=d.args.args[0]),ObjectToken)or ReferenceType not in A.typ.mro:logger.debug('Discarding call to weakref.ReferenceType.__call__ with non-ref object');return
		op.return_value(d,PropVar(A,SynthProp.WEAKREF_OBJ))
@native_function('weakref.proxy',spec='lambda object, callback=None, /: 1')
def proxy(op,d):
	A,*B=d.args.args
	if isinstance(A,Token|ConstraintVar):op.return_value(d,A)
	if B and isinstance((C:=B[0]),Token|ConstraintVar):op.invoke_object(C,replace(d,args=AbstractArgs.seq(A),res=None,parent=ListenerKey(Listener.NATIVE_WEAKREF_CALLBACK,parent=d.parent)))
@native_type(Dict,Object,tname='weakref.WeakKeyDictionary',unsupported_methods=('keyrefs',))
class WeakKeyDictionary(NativeType):0
@native_type(Dict,Object,tname='weakref.WeakValueDictionary',unsupported_methods=('valuerefs',))
class WeakValueDictionary(NativeType):0
@native_function('weakref.finalize',spec='lambda obj, func, /, *args,  **kwargs: 2')
def finalize(op,d):
	C,A,*B=d.args.args
	if isinstance(A,Token|ConstraintVar):op.return_value(d,A);op.invoke_object(A,replace(d,args=replace(d.args,args=tuple(B),num_definite_pos_args=d.args.num_definite_pos_args-2),res=None,parent=ListenerKey(Listener.NATIVE_WEAKREF_FINALIZE,parent=d.parent)))
model={'ref':ReferenceType,'proxy':proxy,'ReferenceType':ReferenceType,'WeakMethod':ReferenceType,'WeakSet':Set,'WeakKeyDictionary':WeakKeyDictionary,'WeakValueDictionary':WeakValueDictionary,'finalize':finalize}