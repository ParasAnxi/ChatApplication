from __future__ import annotations
import inspect,logging,re
from importlib.metadata import Distribution,DistributionFinder,MetadataPathFinder
from typing import TYPE_CHECKING
if TYPE_CHECKING:from collections.abc import Collection,Iterable,Sequence;from pathlib import Path
logger=logging.getLogger(__name__)
def normalize(name):return re.sub('[-_.]+','-',name).lower()
def _get_distributions(sys_path):return MetadataPathFinder.find_distributions(context=DistributionFinder.Context(path=[str(A)for A in sys_path if A.name=='site-packages']))
def pkg_to_dist(sys_path):
	A={}
	for C in _get_distributions(sys_path):
		D=C.metadata['Name']
		for B in _top_level(C):
			if B in A:logger.warning("Package '%s' is in multiple distributions: '%s' and '%s'",B,A[B],D)
			A[B]=D
	return A
def dist_to_pkgs(sys_path):return{normalize(A.metadata['Name']):_top_level(A)for A in _get_distributions(sys_path)}
def _top_level(dist):return _top_level_declared(dist)or _top_level_inferred(dist)
def _top_level_declared(dist):return(dist.read_text('top_level.txt')or'').split()
def _top_level_inferred(dist):
	if(A:=dist.files):return{B for A in A if A.suffix=='.py'and(B:=A.parts[0]if len(A.parts)>1 else inspect.getmodulename(A))and'.'not in B}
	return()